package com.trabajoSpring.demo.strategy;

import java.math.BigDecimal;

public class SinDescuentoStrategy implements CostoAlquilerStrategy{

    @Override
    public BigDecimal calcularCosto(BigDecimal precioPorDia, long cantidadDias) {
        return precioPorDia.multiply(BigDecimal.valueOf(cantidadDias));
        
    }

}
