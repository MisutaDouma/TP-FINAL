package com.trabajoSpring.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionAlumnosApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionAlumnosApplication.class, args);
	}

}
