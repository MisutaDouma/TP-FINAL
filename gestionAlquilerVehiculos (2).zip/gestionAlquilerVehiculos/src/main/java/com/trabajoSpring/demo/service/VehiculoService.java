package com.trabajoSpring.demo.service;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import com.trabajoSpring.demo.model.Auto;
import com.trabajoSpring.demo.model.Moto;
import com.trabajoSpring.demo.model.Vehiculo;
import com.trabajoSpring.demo.repository.VehiculoRepository;

@Service 
public class VehiculoService {

    private final VehiculoRepository vehiculos;

    public VehiculoService(VehiculoRepository vehiculos) {
        this.vehiculos = vehiculos;
    }

    @Transactional 
    public Vehiculo registrarVehiculo(Vehiculo vehiculo){
        if(vehiculo == null){
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "El vehiculo no puede ser nulo");
        }
        if(vehiculo.getId() != null && vehiculos.existsById(vehiculo.getId())){
            throw new ResponseStatusException(HttpStatus.CONFLICT, "El vehiculo ya existe");
        }

        return vehiculos.save(vehiculo);
    }

    @Transactional (readOnly = true )
    public List<Vehiculo> listarVehiculos(){
        return vehiculos.findAll();
    }

    @Transactional (readOnly = true)
    public Vehiculo buscarVehiculoPorId(Long id){
        return vehiculos.findById(id).orElseThrow(()->
            new ResponseStatusException(
                HttpStatus.NOT_FOUND,"Vehiculo inexistente"
            )
        );

    }

    @Transactional 
    public Vehiculo modificarVehiculo(Vehiculo datos){
        if(datos == null || datos.getId()== null){
            throw new ResponseStatusException(
                HttpStatus.BAD_REQUEST,"datos del vehiculo invalidos"
            );
        }

        Vehiculo vehiculo = buscarVehiculoPorId(datos.getId());

        if(!(vehiculo instanceof Auto && datos instanceof Auto)
            && !(vehiculo instanceof Moto && datos instanceof Moto)){
            throw new ResponseStatusException(
                HttpStatus.BAD_REQUEST,"No se puede cambiar el tipo de vehiculo"
            );
        }

        vehiculo.setMarca(datos.getMarca());
        vehiculo.setPatente(datos.getPatente());
        vehiculo.setModelo(datos.getModelo());
        vehiculo.setAnio(datos.getAnio());
        vehiculo.setPrecioPorDia(datos.getPrecioPorDia());
        vehiculo.setDisponible(datos.isDisponible());

        if(vehiculo instanceof Auto && datos instanceof Auto){
            Auto auto = (Auto) vehiculo;
            Auto nuevoAuto = (Auto) datos;

            auto.setCantidadPuertas(nuevoAuto.getCantidadPuertas());

        }else if(vehiculo instanceof Moto && datos instanceof Moto){
            Moto moto = (Moto) vehiculo;
            Moto nuevaMoto = (Moto) datos;

            moto.setCilindrada(nuevaMoto.getCilindrada());
        }

        return vehiculos.save(vehiculo);
    }
    
    @Transactional 
    public void  eliminarVehiculo(Long id){
        Vehiculo vehiculo = buscarVehiculoPorId(id);
        vehiculos.delete(vehiculo);
    }

}
