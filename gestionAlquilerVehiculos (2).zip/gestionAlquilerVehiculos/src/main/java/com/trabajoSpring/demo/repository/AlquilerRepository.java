package com.trabajoSpring.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.trabajoSpring.demo.model.Alquiler;

public interface AlquilerRepository extends JpaRepository<Alquiler, Long> {
    List<Alquiler> findByClienteId(Long clienteId);
}
