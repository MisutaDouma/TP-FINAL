package com.trabajoSpring.demo.service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import com.trabajoSpring.demo.Factory.CostoAlquilerFactory;
import com.trabajoSpring.demo.Factory.TipoCostoAlquiler;
import com.trabajoSpring.demo.dto.AlquilerRequestDTO;
import com.trabajoSpring.demo.dto.AlquilerResponseDTO;
import com.trabajoSpring.demo.dto.AlquilerUpdateDTO;
import com.trabajoSpring.demo.model.Alquiler;
import com.trabajoSpring.demo.model.Cliente;
import com.trabajoSpring.demo.model.Vehiculo;
import com.trabajoSpring.demo.repository.AlquilerRepository;
import com.trabajoSpring.demo.repository.ClienteRepository;
import com.trabajoSpring.demo.strategy.CostoAlquilerStrategy;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.Authentication;

@Service 
public class AlquilerService {
    private final AlquilerRepository alquileres;
    private final ClienteService clienteService;
    private final VehiculoService vehiculoService;
    private final ClienteRepository clienteRepository;

    public AlquilerService(
        AlquilerRepository alquileres,
        ClienteService clienteService, 
        VehiculoService vehiculoService,
        ClienteRepository clienteRepository){
            this.alquileres = alquileres;
            this.clienteService= clienteService;
            this.vehiculoService= vehiculoService;
            this.clienteRepository= clienteRepository;
        }

    @Transactional 
    public AlquilerResponseDTO registrarAlquiler(AlquilerRequestDTO alquilerDTO){
        
        //validamos que el DTO no sea nulo y que tenga el id del vehiculo
        if(alquilerDTO == null || alquilerDTO.getVehiculoId() ==null){
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Los datos del alquiler son obligatorios");
        }
        //obtenemos el usuario autenticado
        Authentication autentificacion = SecurityContextHolder.getContext().getAuthentication();
        
        //obtenemos el nombre de usuario del cliente autenticado
        String username = autentificacion.getName();
        
        //verificamos si el usuario autenticado es un administrador
        boolean esAdmin= autentificacion.getAuthorities().stream().anyMatch(auth -> auth.getAuthority().equals("ROLE_ADMIN"));    
        //si es administrador, el cliente debe ser especificado en el DTO
        if(esAdmin && alquilerDTO.getClienteId() == null){
            throw new ResponseStatusException(
                HttpStatus.BAD_REQUEST,"El administreador debe indicar el cliente para registrar un alquiler");
        }
        
        Cliente cliente;
        
        //si es administrador, buscamos el cliente por id, si no, buscamos el cliente por username
        if(esAdmin){
            cliente = clienteService.buscarClientePorId(alquilerDTO.getClienteId());
        }else{
            cliente = clienteRepository.findByUserUsername(username)
            .orElseThrow(() -> new ResponseStatusException(
                    HttpStatus.NOT_FOUND,
                    "Cliente no encontrado"));
        }

        //buscamos el vehiculo por id
        Vehiculo vehiculo = vehiculoService.buscarVehiculoPorId(alquilerDTO.getVehiculoId());
        
        //creamos variables de fechas para utilizarlas
        LocalDate inicio = alquilerDTO.getFechaInicio();
        LocalDate fin = alquilerDTO.getFechaFin();
        
        if(inicio == null || fin == null){
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Las fechas son obligatorias");

        }
        if(!inicio.isBefore(fin)){
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"La fecha de inicio debe ser anterior a la fecha de fin");

        }
        if(vehiculo.isDisponible() == false){
           throw new ResponseStatusException(HttpStatus.CONFLICT,"El vehiculo no esta disponible");

        } 

        //creamos una variable para obtener la distancia entre los dias de inicio y fin
        long cantidadDias = ChronoUnit.DAYS.between(inicio, fin);

        TipoCostoAlquiler tipo = alquilerDTO.getTipoCosto();

        if(tipo == null){
            tipo = TipoCostoAlquiler.SIN_DESCUENTO;
        }

        CostoAlquilerStrategy estrategia = CostoAlquilerFactory.crear(tipo);


        //calculamos el subtotal, como cantidadDias es un long debemos utilizar multiply
        BigDecimal subtotal = estrategia.calcularCosto(vehiculo.getPrecioPorDia(), cantidadDias);

        Alquiler alquiler = new Alquiler();
        
        alquiler.setCliente(cliente);
        alquiler.setFechaInicio(inicio);
        alquiler.setFechaFin(fin);
        alquiler.setCosto(subtotal);
        alquiler.setVehiculo(vehiculo);
        alquiler.setTipoCosto(tipo);

        vehiculo.setDisponible(false);

        
        Alquiler alquilerGuardado = alquileres.save(alquiler);

        return convertirAResponseDTO(alquilerGuardado);

    };

    @Transactional (readOnly = true)
    public List<AlquilerResponseDTO> listarAlquileres(){

        Authentication autentificacion = SecurityContextHolder.getContext().getAuthentication();

        boolean esAdmin= autentificacion.getAuthorities().stream().anyMatch(auth -> auth.getAuthority().equals("ROLE_ADMIN"));

        List<Alquiler> lista;

        if(esAdmin){
            lista = alquileres.findAll();
        }else{
            String username= autentificacion.getName();

            Cliente cliente = clienteRepository.findByUserUsername(username)
                    .orElseThrow(()-> new ResponseStatusException(HttpStatus.NOT_FOUND, "Cliente no encontrado"));
            lista = alquileres.findByClienteId(cliente.getId());
        }
        return lista.stream()
                .map(alquiler -> convertirAResponseDTO(alquiler))
                .toList();

    };

    @Transactional (readOnly = true)
    public AlquilerResponseDTO  buscarAlquilerPorId(Long id){
        Alquiler alquiler = obtenerEntidadPorId(id);

        Authentication autentificacion = SecurityContextHolder.getContext().getAuthentication();

        boolean esAdmin = autentificacion.getAuthorities().stream().anyMatch(auth -> auth.getAuthority().equals("ROLE_ADMIN"));

        if(!esAdmin){
            String username = autentificacion.getName();

            Cliente cliente = clienteRepository.findByUserUsername(username)
                    .orElseThrow(()-> new ResponseStatusException(HttpStatus.NOT_FOUND, "Cliente no encontrado"));
            
            if(!alquiler.getCliente().getId().equals(cliente.getId())){
                throw new ResponseStatusException(HttpStatus.FORBIDDEN, "No tiene permiso para acceder a este alquiler");
            }
        }



        return convertirAResponseDTO(alquiler);

    };

    private Alquiler obtenerEntidadPorId(Long id) {
    return alquileres.findById(id)
            .orElseThrow(() -> new ResponseStatusException(
                    HttpStatus.NOT_FOUND, "Alquiler no encontrado"));
}

    @Transactional
    public AlquilerResponseDTO modificarAlquiler(AlquilerUpdateDTO datos){
        if(datos == null || datos.getId() == null ||
            datos.getFechaInicio() == null || datos.getFechaFin()== null){
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Datos del alquiler invalidos");
            }
        Alquiler alquiler = obtenerEntidadPorId(datos.getId());

        Authentication autentificacion = SecurityContextHolder.getContext().getAuthentication();

        boolean esAdmin = autentificacion.getAuthorities().stream().anyMatch(auth -> auth.getAuthority().equals("ROLE_ADMIN"));

        if(!esAdmin){
            String username = autentificacion.getName();

            Cliente cliente = clienteRepository.findByUserUsername(username)
                    .orElseThrow(()-> new ResponseStatusException(HttpStatus.NOT_FOUND, "Cliente no encontrado"));
            
            if(!alquiler.getCliente().getId().equals(cliente.getId())){
                throw new ResponseStatusException(HttpStatus.FORBIDDEN, "No tiene permiso para modificar este alquiler");
            }
        }

        LocalDate nuevoInicio = datos.getFechaInicio();
        LocalDate nuevoFin = datos.getFechaFin();

        if(!nuevoInicio.isBefore(nuevoFin)){
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"La fecha de inicio debe ser anterior a la fecha de fin");

        }

        Vehiculo vehiculo = alquiler.getVehiculo();

        long cantidadDias = ChronoUnit.DAYS.between(nuevoInicio, nuevoFin);

        TipoCostoAlquiler tipo = alquiler.getTipoCosto();

        if(tipo == null ){
            tipo = TipoCostoAlquiler.SIN_DESCUENTO;
            alquiler.setTipoCosto(tipo);
        }

        CostoAlquilerStrategy estrategia = CostoAlquilerFactory.crear(tipo);

        BigDecimal subtotal = estrategia.calcularCosto(vehiculo.getPrecioPorDia(), cantidadDias);

        alquiler.setFechaInicio(nuevoInicio);
        alquiler.setFechaFin(nuevoFin);
        alquiler.setCosto(subtotal);

        Alquiler AlquilerModificado = alquileres.save(alquiler);
        return convertirAResponseDTO(AlquilerModificado);

    };

    @Transactional
    public void eliminarAlquiler(Long id){
        Alquiler alquiler = obtenerEntidadPorId(id);

        Authentication autentificacion = SecurityContextHolder.getContext().getAuthentication();

        boolean esAdmin = autentificacion.getAuthorities().stream().anyMatch(auth -> auth.getAuthority().equals("ROLE_ADMIN"));

        if(!esAdmin){
            String username = autentificacion.getName();

            Cliente cliente = clienteRepository.findByUserUsername(username)
                    .orElseThrow(()-> new ResponseStatusException(HttpStatus.NOT_FOUND, "Cliente no encontrado"));
            
            if(!alquiler.getCliente().getId().equals(cliente.getId())){
                throw new ResponseStatusException(HttpStatus.FORBIDDEN, "No tiene permiso para eliminar este alquiler");
            }
        }
        alquiler.getVehiculo().setDisponible(true);
        alquileres.delete(alquiler);
        

    };

    private AlquilerResponseDTO convertirAResponseDTO(Alquiler alquiler){
        AlquilerResponseDTO dto = new AlquilerResponseDTO();

        dto.setId(alquiler.getId());
        dto.setFechaInicio(alquiler.getFechaInicio());
        dto.setFechaFin(alquiler.getFechaFin());
        dto.setCosto(alquiler.getCosto());
        dto.setClienteNombre(alquiler.getCliente().getNombre());
        dto.setVehiculoModelo(alquiler.getVehiculo().getModelo());

        return dto;
    }

}
