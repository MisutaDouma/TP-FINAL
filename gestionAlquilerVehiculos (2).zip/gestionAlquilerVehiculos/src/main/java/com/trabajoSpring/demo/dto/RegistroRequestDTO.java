package com.trabajoSpring.demo.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter 
@Setter 
@NoArgsConstructor 
@AllArgsConstructor 
public class RegistroRequestDTO {
    
    private String username;
    private String password;

    private String nombre;
    private String dni;
    private String email;

}
