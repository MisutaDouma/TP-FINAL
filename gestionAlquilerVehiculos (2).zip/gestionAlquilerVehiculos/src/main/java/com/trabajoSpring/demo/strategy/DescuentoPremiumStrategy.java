package com.trabajoSpring.demo.strategy;

import java.math.BigDecimal;

public class DescuentoPremiumStrategy implements CostoAlquilerStrategy{

    @Override
    public BigDecimal calcularCosto(BigDecimal precioPorDia, long cantidadDias) {
        
        BigDecimal subtotal = precioPorDia.multiply(BigDecimal.valueOf(cantidadDias));

        BigDecimal descuento = subtotal.multiply(new BigDecimal("0.20"));

        return subtotal.subtract(descuento);
    }

}
