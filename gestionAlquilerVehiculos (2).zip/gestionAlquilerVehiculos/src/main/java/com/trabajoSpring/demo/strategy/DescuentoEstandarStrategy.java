package com.trabajoSpring.demo.strategy;

import java.math.BigDecimal;

public class DescuentoEstandarStrategy implements CostoAlquilerStrategy{

    @Override
    public BigDecimal calcularCosto(BigDecimal precioPorDia, long cantidadDias) {
        BigDecimal subtotal = precioPorDia.multiply(BigDecimal.valueOf(cantidadDias));

        BigDecimal descuento = subtotal.multiply(new BigDecimal("0.10"));

        return subtotal.subtract(descuento);
        
    }

}
