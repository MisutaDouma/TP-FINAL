package com.trabajoSpring.demo.controller;

import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.trabajoSpring.demo.model.Cliente;
import com.trabajoSpring.demo.service.ClienteService;

@RestController
@RequestMapping("/api/clientes")

public class ClienteController {
    private final ClienteService clienteService;

    public ClienteController(ClienteService clienteService){
        this.clienteService=clienteService;
    }

    @PostMapping //@RequestBody: obtiene datos del cuerpo de la solicitud.
    public Cliente registrarCliente(@RequestBody Cliente cliente){
        return clienteService.registrarCliente(cliente);
    }

    @GetMapping 
    public List<Cliente> listarCliente(){
        return clienteService.listarClientes();
    }

    @GetMapping("/{id}") //@PathVariable: obtiene datos directamente de la URL
    public Cliente buscarClientePorId(@PathVariable Long id){
        return clienteService.buscarClientePorId(id);
    }

    @PutMapping 
    public Cliente modificarCliente(@RequestBody Cliente cliente){
        return clienteService.modificarCliente(cliente);
    }

    @DeleteMapping("/{id}") 
    public void eliminarCliente(@PathVariable Long id){
        clienteService.eliminarCliente(id);
    }


}
