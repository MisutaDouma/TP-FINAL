package com.trabajoSpring.demo.security;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;
import java.io.IOException;


@Component
public class AuthEntryPointJwt  implements AuthenticationEntryPoint {
    @Override
    public void commence(
            HttpServletRequest request,
            HttpServletResponse response,
            AuthenticationException authException
    ) throws IOException {
        response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Error: Unauthorized");
        //borrar esto de abajo
        System.out.println("ERROR ORIGINAL: " + request.getAttribute(
        "jakarta.servlet.error.request_uri"));
        System.out.println("STATUS ORIGINAL: " + request.getAttribute(
        "jakarta.servlet.error.status_code"));
        //hasta aca
    }
}
