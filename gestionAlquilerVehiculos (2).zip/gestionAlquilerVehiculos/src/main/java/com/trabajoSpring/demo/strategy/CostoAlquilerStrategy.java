package com.trabajoSpring.demo.strategy;

import java.math.BigDecimal;

public interface CostoAlquilerStrategy {

    BigDecimal calcularCosto(BigDecimal precioPorDia, long cantidadDias);

}
