package com.trabajoSpring.demo.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.trabajoSpring.demo.service.CustomUserDetailsService;
import com.trabajoSpring.demo.service.TokenRevocationService;

@Configuration
public class WebSecurityConfig {

    private final CustomUserDetailsService userDetailsService;
    private final TokenRevocationService tokenRevocationService;
    private final JwtUtil jwtUtil;
    private final AuthEntryPointJwt unauthorizedHandler;

    public WebSecurityConfig(CustomUserDetailsService userDetailsService,
                             TokenRevocationService tokenRevocationService,
                             JwtUtil jwtUtil,
                             AuthEntryPointJwt unauthorizedHandler) {
        this.userDetailsService = userDetailsService;
        this.tokenRevocationService = tokenRevocationService;
        this.jwtUtil = jwtUtil;
        this.unauthorizedHandler = unauthorizedHandler;
    }

    @Bean
    public AuthenticationManager authenticationManager(
            AuthenticationConfiguration authenticationConfiguration) throws Exception {
        return authenticationConfiguration.getAuthenticationManager();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .csrf(csrf -> csrf.disable()) // API REST sin sesiones, autenticada por Bearer JWT.
                .cors(cors -> cors.disable()) // Conserva la configuración previa de la demo.
                .headers(headers -> headers.frameOptions(frame -> frame.sameOrigin()))
                .exceptionHandling(exceptions -> exceptions.authenticationEntryPoint(unauthorizedHandler))
                .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .authorizeHttpRequests(authorize -> authorize
                        //cualquiera puede registrarse o iniciar sesion, pero para cerrar sesion se requiere autenticacion, un JTW valido
                        .requestMatchers(HttpMethod.POST, "/api/auth/signin", "/api/auth/signup").permitAll()
                        .requestMatchers(HttpMethod.POST, "/api/auth/logout").authenticated()


                        .requestMatchers("/api/test/all", "/h2-console", "/h2-console/**").permitAll()

                        // admin y user pueden consultar
                        .requestMatchers(HttpMethod.GET,"/api/vehiculos","/api/vehiculos/**").hasAnyRole("ADMIN", "USER")

                        // todas las operaciones de vehiculos y clientes requieren rol admin
                        .requestMatchers("/api/vehiculos/**").hasRole("ADMIN")
                        .requestMatchers("/api/clientes","/api/clientes/**").hasRole("ADMIN")
                        
                        // el alquilerService conmtrola que puede gestionar cada uno
                        .requestMatchers("/api/alquileres","/api/alquileres/**").hasAnyRole("ADMIN", "USER")

                        .anyRequest().authenticated()
                );

        http.addFilterBefore(
                new AuthTokenFilter(jwtUtil, userDetailsService, tokenRevocationService),
                UsernamePasswordAuthenticationFilter.class);
        return http.build();
    }
}