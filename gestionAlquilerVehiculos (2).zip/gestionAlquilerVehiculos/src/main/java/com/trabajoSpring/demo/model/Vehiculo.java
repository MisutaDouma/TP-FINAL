package com.trabajoSpring.demo.model;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;



@Entity
@JsonTypeInfo(
    use = JsonTypeInfo.Id.NAME,
    include = JsonTypeInfo.As.PROPERTY,
    property = "tipo"
)
@JsonSubTypes({
    @JsonSubTypes.Type(value = Auto.class, name = "auto"),
    @JsonSubTypes.Type(value = Moto.class, name = "moto")
})

@Getter 
@Setter 
@NoArgsConstructor 
@AllArgsConstructor 
@Table(name = "vehiculos")
@Inheritance (strategy = InheritanceType.JOINED)
public abstract class Vehiculo {
    
    @Id 
    @GeneratedValue (strategy = GenerationType.IDENTITY)
    private Long id;
    private String marca;
    private String patente;
    private String modelo;
    private int anio;
    private BigDecimal precioPorDia;
    private boolean disponible;

}
