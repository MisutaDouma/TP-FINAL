package com.trabajoSpring.demo.service;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import com.trabajoSpring.demo.model.Cliente;
import com.trabajoSpring.demo.repository.ClienteRepository;



@Service 
public class ClienteService {

    private final ClienteRepository clientes;

    public ClienteService(ClienteRepository clientes) {
        this.clientes = clientes;
    }
    // registramos un cliente, si no tiene nombre, dni o email lanzamos una excepcion
    @Transactional 
    public Cliente registrarCliente(Cliente cliente){
        if(cliente == null || cliente.getNombre() == null ||cliente.getNombre().isBlank()||
           cliente.getDni() == null || cliente.getDni().isBlank() || 
           cliente.getEmail() == null || cliente.getEmail().isBlank()){
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Todos los campos son obligatorios");
        }
        return clientes.save(cliente);
    }
    // Listamos todos los clientes, si no hay ninguno lanzamos una excepcion
    @Transactional (readOnly = true )
    public List<Cliente> listarClientes(){
        return clientes.findAll();
    }
    // Buscamos un cliente por id, si no existe lanzamos una excepcion
    @Transactional (readOnly = true)
    public Cliente buscarClientePorId(Long id){
        return clientes.findById(id).orElseThrow(()->
            new ResponseStatusException(HttpStatus.NOT_FOUND, "Cliente inexistente"  ));
    }
    // Modificamos un cliente, si no tiene nombre, dni o email lanzamos una excepcion
    @Transactional 
    public Cliente modificarCliente(Cliente datos){
        if(datos == null || datos.getId() == null || 
            datos.getNombre() == null ||datos.getNombre().isBlank()||
            datos.getDni() == null || datos.getDni().isBlank() || 
            datos.getEmail() == null || datos.getEmail().isBlank()){
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Todos los campos son obligatorios");
        }

        Cliente cliente = buscarClientePorId(datos.getId());
        
        cliente.setNombre(datos.getNombre());
        cliente.setDni(datos.getDni());
        cliente.setEmail(datos.getEmail());

        return clientes.save(cliente);
    }
    // Eliminamos un cliente, si no existe lanzamos una excepcion
    @Transactional 
    public void eliminarCliente(Long id){
        Cliente cliente = buscarClientePorId(id);
        clientes.delete(cliente);
    }
}
