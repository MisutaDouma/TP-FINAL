package com.trabajoSpring.demo.Factory;

import com.trabajoSpring.demo.strategy.CostoAlquilerStrategy;
import com.trabajoSpring.demo.strategy.DescuentoEstandarStrategy;
import com.trabajoSpring.demo.strategy.DescuentoPremiumStrategy;
import com.trabajoSpring.demo.strategy.SinDescuentoStrategy;

public class CostoAlquilerFactory {
    public static CostoAlquilerStrategy crear(TipoCostoAlquiler tipo){

        switch(tipo){
            case SIN_DESCUENTO:
                return new SinDescuentoStrategy();
            case ESTANDAR:
                return new DescuentoEstandarStrategy();
            case PREMIUM:
                return new DescuentoPremiumStrategy();
            default:
                throw new IllegalArgumentException("Tipo de costo invalido");
        }


    }
}
