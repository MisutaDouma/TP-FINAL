package com.trabajoSpring.demo.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import com.trabajoSpring.demo.dto.RegistroRequestDTO;
import com.trabajoSpring.demo.model.Cliente;
import com.trabajoSpring.demo.model.User;
import com.trabajoSpring.demo.repository.ClienteRepository;
import com.trabajoSpring.demo.repository.UserRepository;
import com.trabajoSpring.demo.security.JwtUtil;
import com.trabajoSpring.demo.service.TokenRevocationService;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthenticationManager authenticationManager;
    private final UserRepository userRepository;
    private final PasswordEncoder encoder;
    private final JwtUtil jwtUtils;
    private final TokenRevocationService tokenRevocationService;
    private final ClienteRepository clienteRepository;

    public AuthController(AuthenticationManager authenticationManager,
                          UserRepository userRepository,
                          PasswordEncoder encoder,
                          JwtUtil jwtUtils,
                          TokenRevocationService tokenRevocationService,
                          ClienteRepository clienteRepository) {
        this.authenticationManager = authenticationManager;
        this.userRepository = userRepository;
        this.encoder = encoder;
        this.jwtUtils = jwtUtils;
        this.tokenRevocationService = tokenRevocationService;
        this.clienteRepository = clienteRepository;
    }

    @PostMapping("/signin")
    public String authenticateUser(@RequestBody User user) {
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(user.getUsername(), user.getPassword()));
        UserDetails userDetails = (UserDetails) authentication.getPrincipal();
        return jwtUtils.generateToken(userDetails.getUsername());
    }

    @PostMapping("/signup")
    public String registerUser(@RequestBody RegistroRequestDTO datos) {
        if (userRepository.existsByUsername(datos.getUsername())) {
            return "Error: El nombre de usuario ya está o|cupado!";
        }
        User newUser = new User(null, datos.getUsername(), encoder.encode(datos.getPassword()), "ROLE_USER");
        userRepository.save(newUser);
        
        Cliente nuevoCliente = new Cliente(
            null, datos.getNombre(), datos.getDni(), datos.getEmail(), newUser
        );

        clienteRepository.save(nuevoCliente);
        return "Usuario registrado correctamente!";
    }

    /**
     * Enviar Authorization: Bearer <JWT> sin cuerpo en el POST.
     * El filtro comprueba que el JWT sea válido y no haya sido revocado.
     */
    @PostMapping("/logout")
    public ResponseEntity<String> logout(@RequestHeader("Authorization") String authorization) {
        String jwt = authorization.substring(7); // El filtro ya validó el prefijo Bearer.
        tokenRevocationService.revoke(jwt);
        return ResponseEntity.ok("Sesión cerrada: JWT revocado correctamente.");
    }
}
