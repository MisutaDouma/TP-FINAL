package com.trabajoSpring.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.trabajoSpring.demo.model.Vehiculo;

public interface VehiculoRepository extends JpaRepository<Vehiculo, Long> {

}
