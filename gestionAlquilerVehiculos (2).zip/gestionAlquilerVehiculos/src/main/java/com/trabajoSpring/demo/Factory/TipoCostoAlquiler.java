package com.trabajoSpring.demo.Factory;

public enum TipoCostoAlquiler {
    SIN_DESCUENTO,
    ESTANDAR,
    PREMIUM

}
