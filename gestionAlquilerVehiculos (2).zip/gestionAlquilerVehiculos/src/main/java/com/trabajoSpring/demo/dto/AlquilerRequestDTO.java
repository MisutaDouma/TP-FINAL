package com.trabajoSpring.demo.dto;

import java.time.LocalDate;

import com.trabajoSpring.demo.Factory.TipoCostoAlquiler;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AlquilerRequestDTO {

    private LocalDate fechaInicio;
    private LocalDate fechaFin;
    private Long clienteId;
    private Long vehiculoId;
    private TipoCostoAlquiler tipoCosto;

}
