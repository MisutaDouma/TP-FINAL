package com.trabajoSpring.demo;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class GenerarPassword {

    public static void main(String[] args) {
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

        String password = "admin123";

        String passwordEncriptada = encoder.encode(password);

        System.out.println(passwordEncriptada);
    }
}