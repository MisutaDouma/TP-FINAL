package com.trabajoSpring.demo.controller;

import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.trabajoSpring.demo.dto.AlquilerRequestDTO;
import com.trabajoSpring.demo.dto.AlquilerResponseDTO;
import com.trabajoSpring.demo.dto.AlquilerUpdateDTO;
import com.trabajoSpring.demo.service.AlquilerService;

@RestController 
@RequestMapping("/api/alquileres")
public class AlquilerController {
    private final AlquilerService alquilerService;

    public AlquilerController(AlquilerService alquilerService){
        this.alquilerService=alquilerService;
    }

    @PostMapping
    public AlquilerResponseDTO registrarAlquiler(@RequestBody AlquilerRequestDTO alquilerDTO){
        return alquilerService.registrarAlquiler(alquilerDTO);
    }

    @GetMapping 
    public List<AlquilerResponseDTO> listarAlquileres(){
        return alquilerService.listarAlquileres();
    }

    @GetMapping("/{id}")
    public AlquilerResponseDTO buscarAlquilerPorId(@PathVariable Long id){
        return alquilerService.buscarAlquilerPorId(id);
    }

    @PutMapping ("/{id}")
    public AlquilerResponseDTO modificarAlquiler(@RequestBody AlquilerUpdateDTO datos){
        return alquilerService.modificarAlquiler(datos);
    }

    @DeleteMapping("/{id}")
    public void eliminarAlquiler(@PathVariable Long id){
        alquilerService.eliminarAlquiler(id);
    }

}
