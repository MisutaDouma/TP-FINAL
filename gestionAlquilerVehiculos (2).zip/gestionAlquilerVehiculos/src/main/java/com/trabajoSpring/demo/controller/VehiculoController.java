package com.trabajoSpring.demo.controller;

import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.trabajoSpring.demo.model.Vehiculo;
import com.trabajoSpring.demo.service.VehiculoService;

@RestController
@RequestMapping("/api/vehiculos")
public class VehiculoController {
    private final VehiculoService vehiculoService;

    public VehiculoController(VehiculoService vehiculoService){
        this.vehiculoService=vehiculoService;
    }

    @PostMapping 
    public Vehiculo registrarVehiculo(@RequestBody Vehiculo vehiculo){
        return vehiculoService.registrarVehiculo(vehiculo);
    }

    @GetMapping
    public List<Vehiculo> listarVehiculos(){
        return vehiculoService.listarVehiculos();
    }

    @GetMapping("/{id}")
    public Vehiculo buscarVehiculoPorId(@PathVariable Long id){
        return vehiculoService.buscarVehiculoPorId(id);
    }

    @PutMapping
    public Vehiculo modificarVehiculo(@RequestBody Vehiculo vehiculo){
        return vehiculoService.modificarVehiculo(vehiculo);
        
    }

    @DeleteMapping("/{id}")
    public void eliminarVehiculo(@PathVariable Long id){
        vehiculoService.eliminarVehiculo(id);
    }

}
